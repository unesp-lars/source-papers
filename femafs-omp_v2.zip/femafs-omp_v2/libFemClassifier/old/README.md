# libFemClassifier
Finite Element Machine Classifier

This repository contains the **FEMa** (Finite Element Machine Classifier).

The example and datasets to tests are available into folder example/classify

## Requirements
- LibOPF (https://github.com/jppbsi/LibOPF)
